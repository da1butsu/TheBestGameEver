﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

 [Serializable]public class PlayerProgressLevel
{
    public float fireballDamage;
    public float grenadeDamage;
    public float experienceForNextLevel;

       
}
